package test.constant;

public class CommonConstant {
	
	public static String PRICEUNIT = "$";

}
