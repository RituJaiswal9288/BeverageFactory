package test.service;


public interface MenuProcessingService {
	
	public Double processSingleOrder(String order);
}
