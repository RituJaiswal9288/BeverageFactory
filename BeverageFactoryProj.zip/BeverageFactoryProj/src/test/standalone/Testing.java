package test.standalone;

import test.controller.MenuOrderController;

public class Testing {

	public static void main(String[] args) {
		String sampleOrder = null;
		// sampleOrder = "Chai-sugar";
		//sampleOrder = "Chai-sugar-milk";
		// sampleOrder = "Chai";
		//sampleOrder = "Chai-sugar-milk,Chai,Coffee-milk";
		//sampleOrder = "";
		new MenuOrderController().placeOrder(sampleOrder);
	}

}
